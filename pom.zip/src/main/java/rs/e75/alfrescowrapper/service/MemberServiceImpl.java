package rs.e75.alfrescowrapper.service;

import rs.e75.alfrescowrapper.dao.RestDao;
import rs.e75.alfrescowrapper.exceptions.ForbidenException;
import rs.e75.alfrescowrapper.exceptions.RestException;
import rs.e75.alfrescowrapper.exceptions.ServerNotFoundException;
import rs.e75.alfrescowrapper.exceptions.WebScriptException;
import rs.e75.alfrescowrapper.exceptions.YanadoException;
import rs.e75.alfrescowrapper.model.User;

/**
 * 
 * @author Savic Prvoslav
 * 
 */
public class MemberServiceImpl implements MemberService {

	private RestDao restDao;

	public MemberServiceImpl(RestDao restDao) {
		this.restDao = restDao;
	}

	public String login(User user) throws ForbidenException, YanadoException {

		try {
			String ticket =  restDao.login(user);
			user.setTicket(ticket);
			user.setLoggedIn(true);
			return ticket;
		} catch (RestException e) {

			throw new YanadoException(e);
		} catch (ServerNotFoundException e) {

			throw new YanadoException(e);
		} catch (WebScriptException e) {
			throw new YanadoException(e);
		}

	}

}
