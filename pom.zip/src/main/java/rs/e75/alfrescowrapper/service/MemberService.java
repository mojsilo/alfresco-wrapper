package rs.e75.alfrescowrapper.service;

import rs.e75.alfrescowrapper.exceptions.ForbidenException;
import rs.e75.alfrescowrapper.exceptions.RestException;
import rs.e75.alfrescowrapper.exceptions.ServerNotFoundException;
import rs.e75.alfrescowrapper.exceptions.WebScriptException;
import rs.e75.alfrescowrapper.exceptions.YanadoException;
import rs.e75.alfrescowrapper.model.User;

/**
 * 
 * @author Savic Prvoslav
 * 
 */
public interface MemberService {
	
	/**
	 * Login user, 
	 *  required is to set username and password to user object
	 *  
	 * @param user
	 * @return
	 * @throws ForbidenException
	 * @throws YanadoException
	 */
	String login(User user) throws ForbidenException, YanadoException;
}
