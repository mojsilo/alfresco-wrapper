package rs.e75.alfrescowrapper.service;



/**
 * 
 * @author Savic Prvoslav
 * @revision r1
 */
public interface TimeElapsedService {

	void logRestTime(String name, org.apache.commons.lang.time.StopWatch stopWatch);

}
