package rs.e75.alfrescowrapper.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import rs.e75.alfrescowrapper.constants.ContentModel;
import rs.e75.alfrescowrapper.exceptions.ForbidenException;
import rs.e75.alfrescowrapper.exceptions.YanadoException;
import rs.e75.alfrescowrapper.model.ActionReturn;
import rs.e75.alfrescowrapper.model.Node;
import rs.e75.alfrescowrapper.model.NodePropertyAbstraction;
import rs.e75.alfrescowrapper.model.NodeRef;
import rs.e75.alfrescowrapper.model.User;
import rs.e75.alfrescowrapper.service.MemberService;
import rs.e75.alfrescowrapper.service.ServiceFactory;

/**
 * 
 * @author Savic Prvoslav
 * 
 *         Logovanje Ucitavanje Noda Listanje foldera Pretraga
 * 
 *         Create folder Delete Node Update node Upload fajla
 * 
 */
public class LoginTest {

	private static Logger logger = Logger.getLogger(LoginTest.class);

	private static String DESCRIPTION = "Ovo ce biti opis";
	private static String DESCRIPTION1 = "Ovo ce biti opis 1";
	private static String FOLDER_NAME = "new folder";
	private static String FILE_NAME = "slika1.png";
	private static String FILE_PATH = "C:\\Users\\Savic Prvoslav\\Desktop\\yanado-app\\assets\\img\\acc-img2.png";
	private static String COMPANY_HOME_REF = "workspace://SpacesStore/235b61d8-2676-4b91-ab85-5d2acaea9d66";

	private static String USERNAME = "admin";
	private static String PASS = "admin";
	private static String serverPath = "http://localhost:8080/alfresco/";

	/**
	 * This example shows how to login.
	 * 
	 * 
	 * @return
	 */
	private static User loginExample() {
		MemberService memberService = ServiceFactory.getFactory(serverPath)
				.getMemberService();

		User user = new User();
		user.setUsername(USERNAME);
		user.setPassword(PASS);

		try {

			logger.debug(memberService.login(user));

		} catch (ForbidenException e) {
			e.printStackTrace();
		} catch (YanadoException e) {
			e.printStackTrace();
		}

		return user;
	}

	/**
	 * Company home is starting point in alfresco, company home ref is hard
	 * coded and should be changed when enviroment changes
	 * 
	 * @param user
	 * @return
	 */
	private static Node loadCompanyHome(User user) {

		Node companyHomeNode = null;
		try {
			NodeRef nodeRef = new NodeRef(COMPANY_HOME_REF);

			companyHomeNode = ServiceFactory.getFactory(serverPath)
					.getNodeService()
					.loadNode(nodeRef, user, "loadCompanyHome");
		} catch (YanadoException e) {

			e.printStackTrace();
		}
		return companyHomeNode;
	}

	/**
	 * Uploading file from local hard disc to folder(node) on server
	 * 
	 * @param user
	 * @param node
	 * @return
	 */
	private static Node uploadFile(User user, Node node) {
		try {
			NodePropertyAbstraction abstraction = new NodePropertyAbstraction(
					new Node());
			Map<String, Object> map = new HashMap<String, Object>();
			map.put(ContentModel.NODE_NAME, null);
			map.put(ContentModel.NODE_DESCRIPTION, null);
			abstraction.getPropertyNode(ContentModel.NODE_NAME).setValue(
					FILE_NAME);
			abstraction.getPropertyNode(ContentModel.NODE_DESCRIPTION)
					.setValue(DESCRIPTION1);

			ActionReturn actionReturn = ServiceFactory.getFactory(serverPath)
					.getNodeService()
					.upload(user, abstraction, node.getNodeRef(), FILE_PATH);

			return actionReturn.getFistNode();

		} catch (YanadoException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Creating folder in folder(node)
	 * 
	 * @param user
	 * @param node
	 * @return
	 */
	private static Node createFolder(User user, Node node) {
		try {
			NodePropertyAbstraction abstraction = new NodePropertyAbstraction(
					new Node());
			Map<String, Object> map = new HashMap<String, Object>();
			map.put(ContentModel.NODE_NAME, null);
			map.put(ContentModel.NODE_DESCRIPTION, null);

			abstraction.getPropertyNode(ContentModel.NODE_NAME).setValue(
					FOLDER_NAME);
			abstraction.getPropertyNode(ContentModel.NODE_DESCRIPTION)
					.setValue(DESCRIPTION1);
			abstraction.getModifiedNodeProperties();
			ActionReturn actionReturn;

			actionReturn = ServiceFactory.getFactory(serverPath)
					.getNodeService()
					.createFolder(user, abstraction, node.getNodeRef());

			Node createdFolder = actionReturn.getFistNode();
			return createdFolder;

		} catch (YanadoException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Deleting file/folder on server , file and folder are represented with
	 * node
	 * 
	 * @param user
	 * @param node
	 */
	private static void delete(User user, Node node) {
		try {
			ServiceFactory.getFactory(serverPath).getNodeService()
					.executeDelete(user, node);
		} catch (YanadoException e) {
			e.printStackTrace();
		}
	}

	/**
	 * UPdating node, and setting description property to @DESCRIPTION
	 * 
	 * @param user
	 * @param node
	 * @return
	 */
	private static Node updateNode(User user, Node node) {
		try {
			NodePropertyAbstraction abstractionFolderEdit = new NodePropertyAbstraction(
					node);

			abstractionFolderEdit
					.getPropertyNode(ContentModel.NODE_DESCRIPTION).setValue(
							DESCRIPTION);

			ActionReturn actionReturnUpdatedFolder;

			actionReturnUpdatedFolder = ServiceFactory.getFactory(serverPath)
					.getNodeService().updateNode(user, abstractionFolderEdit);

			return actionReturnUpdatedFolder.getFistNode();
		} catch (YanadoException e) {

			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Demostrates login , load company home, creting folder, updating folder,
	 * deleting folder, uploading file and deleting file.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		logger.debug("Test start---------------------");

		User user = loginExample();
		logger.debug("LOGIN OK-----------------------");

		Node companyHOme = loadCompanyHome(user);
		logger.debug("COMPANY HOME LOAD OK-----------");

		Node newFolder = createFolder(user, companyHOme);
		logger.debug("FOLDER CREATE OK---------------");

		Node newFolderUpdate = updateNode(user, newFolder);
		logger.debug("FOLDER UPDATED OK---------------"
				+ newFolderUpdate.getPropertie(ContentModel.NODE_DESCRIPTION));

		delete(user, newFolder);
		logger.debug("FOLDER DELETED OK---------------");

		Node content = uploadFile(user, companyHOme);
		logger.debug("UPLOAD FILE OK------------------" + content.getName());

		delete(user, content);
		logger.debug("DELETE FILE OK------------------");

	}

	/*
	 * public static void main1(String[] args) {
	 * 
	 * MemberService memberService = ServiceFactory.getFactory(serverPath)
	 * .getMemberService();
	 * 
	 * User user = new User(); user.setUsername("admin");
	 * user.setPassword("admin");
	 * 
	 * try {
	 * 
	 * logger.debug(memberService.login(user));
	 * 
	 * NodeRef nodeRef = new NodeRef(
	 * "workspace://SpacesStore/235b61d8-2676-4b91-ab85-5d2acaea9d66"); Node
	 * companyHomeNode = ServiceFactory.getFactory(serverPath).getNodeService()
	 * .loadNode(nodeRef, user, "test"); logger.debug("size " +
	 * companyHomeNode.getName());
	 * 
	 * NodePropertyAbstraction abstraction = new NodePropertyAbstraction( new
	 * Node()); Map<String, Object> map = new HashMap<String, Object>();
	 * map.put(ContentModel.NODE_NAME, null);
	 * map.put(ContentModel.NODE_DESCRIPTION, null);
	 * abstraction.getPropertyNode(ContentModel.NODE_NAME).setValue(
	 * "slika1.png"); abstraction.getPropertyNode(ContentModel.NODE_DESCRIPTION)
	 * .setValue("opis1");
	 * 
	 * ServiceFactory .getFactory(serverPath) .getNodeService() .upload(user,
	 * abstraction, companyHomeNode.getNodeRef(),
	 * "C:\\Users\\Savic Prvoslav\\Desktop\\yanado-app\\assets\\img\\acc-img2.png"
	 * );
	 * 
	 * // List<Node> list = ServiceFactory.getFactory().getNodeService() //
	 * .listChildren(nodeRef, user, RestSetsOfData.FULL, 0, -1); // //
	 * SearchActionReturn actionReturn = //
	 * ServiceFactory.getFactory().getNodeService().search(user, //
	 * "@cm\\:name:\"19665.dcm\" AND TYPE:\"{http://www.alfresco.org/model/content/1.0}content\""
	 * , // ContentModel.getShort(ContentModel.NODE_NAME), true, //
	 * "19665.dcm"); // // logger.debug("size "+
	 * actionReturn.getNodes().size());
	 * 
	 * // NodePropertyAbstraction abstraction=new // NodePropertyAbstraction(new
	 * Node()); // Map<String, Object> map = new HashMap<String, Object>(); //
	 * map.put(ContentModel.NODE_NAME, null); //
	 * map.put(ContentModel.NODE_DESCRIPTION, null); // // //
	 * abstraction.getPropertyNode
	 * (ContentModel.NODE_NAME).setValue("Novi folder 2"); //
	 * abstraction.getPropertyNode
	 * (ContentModel.NODE_DESCRIPTION).setValue("opis"); //
	 * abstraction.getModifiedNodeProperties(); // ActionReturn actionReturn =
	 * // ServiceFactory.getFactory().getNodeService().createFolder(user, //
	 * abstraction, companyHomeNode.getNodeRef()); // Node createdFolder =
	 * actionReturn.getFistNode(); // // //--- // NodePropertyAbstraction
	 * abstractionFolderEdit=new // NodePropertyAbstraction(createdFolder); //
	 * abstractionFolderEdit
	 * .getPropertyNode(ContentModel.NODE_DESCRIPTION).setValue
	 * ("Ako zelis da me vidis ne trazi me na mestima"); // ActionReturn
	 * actionReturnUpdatedFolder = //
	 * ServiceFactory.getFactory().getNodeService().updateNode(user, //
	 * abstractionFolderEdit); // System.out.println( //
	 * actionReturnUpdatedFolder
	 * .getFistNode().getStringPropertie(ContentModel.NODE_DESCRIPTION));
	 * 
	 * // NodeRef removeFolder=new //
	 * NodeRef("204f9f64-cb43-45c1-8acd-0939a886f484"); // Node n=new
	 * Node(removeFolder); //
	 * ServiceFactory.getFactory().getNodeService().executeDelete(user, // n);
	 * 
	 * } catch (ForbidenException e) { e.printStackTrace(); } catch
	 * (YanadoException e) { e.printStackTrace(); }
	 * 
	 * }
	 */
}
